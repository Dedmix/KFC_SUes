﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace KFCApp.AppPages
{
	public partial class Authorization : Page
	{
		public Authorization()
		{
			InitializeComponent();
		}

		private void OnLogin(object sender, RoutedEventArgs e)
		{
			if (Lib.Connector.Authorize(Phone.Text, Password.Password) == true)
			{
				var profile = Lib.Connector.GetMyProfile();
				if (profile == null)
                {
					MessageBox.Show("Ошибка авторизации");
					return;
                }

				var userRole = (AppData.Role)profile.Role;

				switch (userRole)
                {
					case AppData.Role.SuperUser:
						// open SuperUser Page...
						break;
					case AppData.Role.Manager:
						// open Manager Page...
						break;

					// etc...

					default: return;
                }
			}
			else
			{
				MessageBox.Show("Неверный логин/пароль");
			}
		}
	}
}
